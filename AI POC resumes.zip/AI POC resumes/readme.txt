javac -cp "pdfbox-3.0.5.jar;pdfbox-io-3.0.5.jar;fontbox-3.0.5.jar;commons-logging-1.2.jar" PDFZipResumeAnalyzer.java
java -cp ".;pdfbox-3.0.5.jar;pdfbox-io-3.0.5.jar;fontbox-3.0.5.jar;commons-logging-1.2.jar" PDFZipResumeAnalyzer



ref#
https://www.apache.org/dyn/closer.lua/pdfbox/3.0.5/fontbox-3.0.5.jar
https://mvnrepository.com/artifact/commons-logging/commons-logging/1.2