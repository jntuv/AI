import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.Loader;


public class PDFZipResumeAnalyzer extends JFrame {

    private JTextField jdField, zipField;
    private JTextArea resultArea;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PDFZipResumeAnalyzer().setVisible(true));
    }

    public PDFZipResumeAnalyzer() {
        setTitle("AI PDF Resume Analyzer (POC)");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel top = new JPanel(new GridLayout(3, 3, 5, 5));

        jdField = new JTextField();
        zipField = new JTextField();

        JButton browseJD = new JButton("Browse JD");
        JButton browseZip = new JButton("Browse ZIP");
        JButton analyzeBtn = new JButton("Analyze");

        browseJD.addActionListener(e -> chooseFile(jdField));
        browseZip.addActionListener(e -> chooseFile(zipField));
        analyzeBtn.addActionListener(e -> analyzeAction());

        top.add(new JLabel("Job Description File:"));
        top.add(jdField);
        top.add(browseJD);
        top.add(new JLabel("Resumes ZIP File:"));
        top.add(zipField);
        top.add(browseZip);
        top.add(new JLabel(""));
        top.add(new JLabel(""));
        top.add(analyzeBtn);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        JScrollPane scroll = new JScrollPane(resultArea);

        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
    }

    private void chooseFile(JTextField field) {
        JFileChooser fc = new JFileChooser();
        int res = fc.showOpenDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            field.setText(fc.getSelectedFile().getAbsolutePath());
        }
    }

    private void analyzeAction() {
        try {
            String jdText = new String(Files.readAllBytes(Path.of(jdField.getText()))).toLowerCase();
            Set<String> jdWords = new HashSet<>(Arrays.asList(jdText.split("\\W+")));

            File tempDir = Files.createTempDirectory("resumes").toFile();
            unzip(zipField.getText(), tempDir.getAbsolutePath());

            File[] files = tempDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".pdf"));
            if (files == null || files.length == 0) {
                JOptionPane.showMessageDialog(this, "No PDF resumes found in ZIP.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.append("Analyzing Resumes...\n\n");

            String bestResume = "";
            double bestScore = 0;

            for (File file : files) {
                String resumeText = extractTextFromPDF(file).toLowerCase();
                Set<String> resumeWords = new HashSet<>(Arrays.asList(resumeText.split("\\W+")));

                Set<String> matched = new HashSet<>(resumeWords);
                matched.retainAll(jdWords);

                double matchPercent = (double) matched.size() / jdWords.size() * 100;
                sb.append(String.format("%s → %.2f%% match%n", file.getName(), matchPercent));

                if (matchPercent > bestScore) {
                    bestScore = matchPercent;
                    bestResume = file.getName();
                }
            }

            sb.append("\nBest Match:\n").append(String.format("%s → %.2f%%", bestResume, bestScore));
            resultArea.setText(sb.toString());

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

   private static String extractTextFromPDF(File file) {
    try (PDDocument document = Loader.loadPDF(file)) { // <-- changed here
        PDFTextStripper stripper = new PDFTextStripper();
        return stripper.getText(document);
    } catch (IOException e) {
        System.out.println("Error reading PDF: " + file.getName());
        return "";
    }
}


    private static void unzip(String zipFilePath, String destDir) throws IOException {
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFilePath))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                File newFile = new File(destDir, entry.getName());
                new File(newFile.getParent()).mkdirs();
                try (FileOutputStream fos = new FileOutputStream(newFile)) {
                    byte[] buffer = new byte[1024];
                    int len;
                    while ((len = zis.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                }
                zis.closeEntry();
            }
        }
    }
}
